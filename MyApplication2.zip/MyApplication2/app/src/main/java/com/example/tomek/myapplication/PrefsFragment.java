package com.example.tomek.myapplication;

import android.os.Bundle;
import android.preference.PreferenceFragment;

/**
 * Created by Tomek on 09.11.2017.
 */

public class PrefsFragment extends PreferenceFragment {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);

        // Load the preferences from an XML resource
        addPreferencesFromResource(R.layout.activity_main);
    }
}
